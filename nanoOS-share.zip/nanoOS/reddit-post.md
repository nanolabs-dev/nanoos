# I tried fitting a whole tiny desktop into one QR code

I wanted to see how much of a desktop I could fit into a single QR code, so I built nanoOS.

It has movable windows, a terminal, notes, a small file viewer and a clock. The actual HTML, CSS and JavaScript are compressed into the URL after the `#`. There's a hosted page, but it only decodes the fragment. It doesn't contain the desktop itself.

The compressed app is 2,790 bytes. It fits in one standard Version 40 QR, with 270 bits left before padding. The build checks it by decoding the QR image and comparing the recovered app byte for byte.

Notes save in the same browser, and the desktop works offline once it's opened. The first scan still needs internet for the decoder. It's a browser interface, so the terminal isn't running commands on the phone itself.

I've tested the desktop and phone-sized browser layouts, but I still need to try the QR with more real phone cameras. If you try it, I'd be interested to know what phone/browser you used and whether anything breaks.

— nanoLabs
